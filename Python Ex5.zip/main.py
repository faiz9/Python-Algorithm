#Python Program 5: Create a program that converts Celsius to Fahrenheit. 

#First step, use input command to let the user insert the value in Celsius

Celsius = float(input('Celsius:'))

#Specify the formula the conversion of Celsius to Fahrenheit
Fahrenheit = 9*Celsius/5+32

#Use to print command to display the answer in Fahrenheit degrees

print("To convert that we value into Fahrenheit we need to multiply it by 9 and then add divide by 5 and add 32 which us", Fahrenheit, "°")