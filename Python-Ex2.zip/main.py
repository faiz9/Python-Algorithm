#Exercise2: Variables and Code Blocks

#Assigning values to the variables

myFirstname = 'Syed'
myLastname = 'Faiz'
myAge = '21'
myCity = 'Walnut Creek'
myExperties = 'HTML, CSS, JS, Java, React, Python, Bootstrap, Angular, JQuery, SASS, and ES6'

#Series of print statements to display sentences using variables 

print('Hi, I am', myFirstname,myLastname)

print('I am', myAge, 'years old')

print('I live in', myCity)

print('I am familar with the following programming languages:',myExperties)